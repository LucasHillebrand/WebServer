//import everthing
const libs = {
    "genFunc":require("./libs/general_functions.js"),
    "http":require("http"),
    "api":require("./api.js")
}

//shortcuts
const genFunc = libs.genFunc.main;
const http = libs.http;
const api = libs.api;

//config
const conf = genFunc.getConfig()

//init http/https server
const srv = {"http":http.createServer(main)}
srv.http.listen(conf.port)

//serverfunctions
function main(req,res){
    //getUrl
    let url = genFunc.specialChar(req.url)
    if(url[url.length - 1] == "/"){url+=conf.startPage}
    
    //BEGIN: scanForAPIRequest

    //API Get
    if(genFunc.getChars(1,conf.api.get.length,url) == conf.api.get && conf.api.get!=""){api.main.getPage(genFunc.toList(url,conf.api.get[conf.api.get.length - 1]),res)}

    //api Proccesss
    else if(genFunc.getChars(1,conf.api.proccess.length,url) == conf.api.proccess && conf.api.proccess != ""){api.main.proccess(genFunc.toList(url,conf.api.proccess[conf.api.proccess.length - 1]),res)}

    //END: scanForAPIRequest

    //sendWebPage
    else {
        console.log("request: "+url)
        genFunc.sendPage(conf.startFolder+url,res)
    }
}