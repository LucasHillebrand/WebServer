//export functions
exports.main= {
    "getPage":get,
    "proccess":proccess
}
//import libs
const libs = {
    "genFunc":require("./libs/general_functions.js")
}

//shorts
const genFunc=libs.genFunc


//begin functions

//get API
function get (lst,res){
    console.log(lst)
    res.end()
}

//proccess API
function proccess (lst,res){
    console.log(lst)
    res.end()
}